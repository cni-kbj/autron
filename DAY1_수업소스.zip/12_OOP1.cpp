﻿// 4_OOP1.cpp     57 page
#include <iostream>

void Add(int ar, int ai, int br, int bi)
{
	ar + br;
	ai + bi;
}
int main()
{
	// 복소수 2개를 더하는 함수를 생각해 봅시다.
	int ar = 1, ai = 1; // 1 + 1i
	int br = 2, bi = 2; // 2 + 2i
	
	Add(ar, ai, br, bi);
}
