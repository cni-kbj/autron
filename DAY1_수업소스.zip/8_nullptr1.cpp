﻿// 11_nullptr1.cpp    54 page

int main()
{
	// 0의 정체 : "0은 정수"지만 포인터로 암시적 형변환된다.
	int  n1 = 0; // ok
	int* p1 = 0; // ok

	// 포인터 0이 있는것이 더욱 안전하고 명확합니다.
	int* p2 = nullptr; // ok.. C++11 부터 포인터 0을 의미
//	int  n2 = nullptr; // error

}
