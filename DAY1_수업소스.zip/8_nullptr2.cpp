﻿#include <iostream>

void foo(void* p) { std::cout << "void*" << std::endl;}
void foo(int n)   { std::cout << "int" << std::endl; }

void goo(char* p) { std::cout << "goo" << std::endl; }

int main()
{
	foo(0); // foo(int)..  0의 정확한 정체는 int 입니다. 포인터가 아닙니다.
			//			단지 포인터로 변환가능할뿐
	foo( static_cast<void*>(0) ); // foo(void*) 이지만 복잡해 보입니다.

	foo(nullptr);
	goo(nullptr); // 가독성도 좋고, 단순해 보입니다.
				  // "포인터 0"이 존재 하므로, 여러관점에서 편리합니다.
}

// git 에 오늘 소스와 내일 사전소스 모두 올리겠습니다.

// "github.com/codenuri/autron"   입니다.

