// 6_STL
#include <iostream>
#include <stack>
#include <vector>
#include <string>  
#include <list>

int main()
{

}

