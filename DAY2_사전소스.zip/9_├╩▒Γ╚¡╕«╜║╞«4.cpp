﻿#include <iostream>

// 선언과 구현의 분리
class Point
{
	int x, y;
public:
	Point(int a = 0, int b = 0) : x(a), y(b) {}
};


int main()
{

}




