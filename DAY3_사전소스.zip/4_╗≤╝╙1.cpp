﻿// 5_상속1.cpp   132page ~
#include <iostream>
#include <string>

class Student 
{				
	std::string name;
	int    age;
	int    id;
};
class Professor
{
	std::string name;
	int    age;
	int    major;
};

int main()
{
	Student s;
	Professor p;
}
