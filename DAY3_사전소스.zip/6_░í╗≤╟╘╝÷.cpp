﻿// 7_가상함수1  144 page ~

#include <iostream>

class Animal
{
public:
	void Cry1() { std::cout << "Animal Cry1" << std::endl; } 
	void Cry2() { std::cout << "Animal Cry2" << std::endl; }
};

class Dog : public Animal
{
public:
	void Cry1() { std::cout << "Dog Cry1" << std::endl; }
	void Cry2() { std::cout << "Dog Cry2" << std::endl; }
};

int main()
{
	Animal a; a.Cry1(); // 1 번 호출
	Dog    d; d.Cry1(); // 2 번 호출

	Animal* p = &d;		

	p->Cry1(); // ?
}
