﻿// 7_가상함수2.cpp  147 page ~

class Shape
{
public:
	virtual void Draw() {};
	virtual void Clone() const {};
	virtual void Move() {};
};
class Rect : public Shape
{
public:
	virtual void draw()  {};
	virtual void Clone() {};
	virtual void Move(int n)  {};
};
int main()
{

}
