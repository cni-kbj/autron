#include <iostream>
#include <vector>
#include <list>
#include <string>

int main()
{
	std::vector<int> v(10);
	v[0] = 10;


}