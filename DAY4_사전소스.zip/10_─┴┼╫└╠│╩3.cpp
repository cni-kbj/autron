#include <iostream>
#include <map>
#include <string>
#include <list>

int main()
{
	std::map<std::string, std::string> m;


}