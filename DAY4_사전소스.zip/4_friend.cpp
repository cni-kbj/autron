class Bike
{
private:
	int gear;

public:
	void setGear(int g) { gear = g; }
};

void FixBike(Bike& b)
{
	b.gear = 10;
}
int main()
{
	Bike b;
	b.gear = 10;
	FixBike(b);
}