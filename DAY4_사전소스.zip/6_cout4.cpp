#include <iostream>

int main()
{
	std::cout << "A" << std::endl;

	std::cout.flush(); // fflush(stdout)
}