#include <iostream>
#include <list>
#include <vector>

int main()
{
	int x[10] = { 1,2,3,4,5,6,7,8,9,10 };
	std::list<int> s = { 1,2,3,4,5,6,7,8,9,10 };

	int* p1 = x;

	std::cout << *p1 << std::endl;
	++p1;
	std::cout << *p1 << std::endl;

}